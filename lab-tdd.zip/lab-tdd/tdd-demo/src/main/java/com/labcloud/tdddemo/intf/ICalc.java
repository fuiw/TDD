package com.labcloud.tdddemo.intf;

public interface ICalc {
    public int add(int a, int b);
}
