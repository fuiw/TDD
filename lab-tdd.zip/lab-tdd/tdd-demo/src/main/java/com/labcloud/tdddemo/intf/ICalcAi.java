package com.labcloud.tdddemo.intf;

public interface ICalcAi {
    public int divByAdd(int a, int b, int x);
}
