package com.labcloud.tdddemo.labTestNg.utils;

import org.testng.reporters.TestHTMLReporter;

public class MyHtmlReporter extends TestHTMLReporter {
}
